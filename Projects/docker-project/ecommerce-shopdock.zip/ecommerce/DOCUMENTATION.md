# 🛍️ ShopDock — Dockerized E-Commerce Application

> A full-stack e-commerce app built with React, Node.js, PostgreSQL, and Redis — fully containerized with Docker and Docker Compose.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Architecture](#2-architecture)
3. [Project Structure](#3-project-structure)
4. [Prerequisites](#4-prerequisites)
5. [Quick Start](#5-quick-start)
6. [How Each Service Works](#6-how-each-service-works)
7. [Docker Concepts Used](#7-docker-concepts-used)
8. [API Reference](#8-api-reference)
9. [Development Mode](#9-development-mode)
10. [Useful Commands](#10-useful-commands)
11. [Practice Exercises](#11-practice-exercises)
12. [Troubleshooting](#12-troubleshooting)

---

## 1. Project Overview

**ShopDock** is a production-grade e-commerce application designed to teach Docker through a real-world project.

### Features

| Feature | Tech Used |
|---------|-----------|
| Product listing with search & filter | React + Vite + Tailwind CSS |
| User auth (register / login / JWT) | Node.js + Express + bcryptjs |
| Shopping cart (session-based) | Redis |
| Order placement with stock management | PostgreSQL (with transactions) |
| Product caching | Redis (5-minute TTL) |
| SPA routing & API proxy | Nginx |
| Multi-stage Docker builds | Docker |
| Service orchestration | Docker Compose |

---

## 2. Architecture

```
                          ┌──────────────────────────────────────────┐
                          │           Docker Network: ecom_network   │
                          │                                          │
Browser ──► Port 3000 ──► │  ┌─────────────┐                        │
                          │  │   Frontend  │ nginx:alpine            │
                          │  │  (React SPA)│ port 80                │
                          │  └──────┬──────┘                        │
                          │         │ /api/* proxy                   │
                          │  ┌──────▼──────┐   ┌──────────────┐    │
                          │  │   Backend   │──►│  PostgreSQL   │    │
                          │  │  (Node.js)  │   │   (port 5432) │    │
                          │  │  port 5000  │   └──────────────┘    │
                          │  └──────┬──────┘   ┌──────────────┐    │
                          │         └──────────►│    Redis      │    │
                          │                    │  (port 6379)  │    │
                          │                    └──────────────┘    │
                          └──────────────────────────────────────────┘

Volumes:
  postgres_data ──► /var/lib/postgresql/data  (persistent DB)
  redis_data    ──► /data                     (persistent cache)
```

### Data Flow

1. User visits `http://localhost:3000`
2. Nginx serves the React SPA
3. React makes API calls to `/api/*`
4. Nginx proxies `/api/*` → `backend:5000`
5. Backend queries PostgreSQL (data) or Redis (cache/cart)
6. Response returns to browser

---

## 3. Project Structure

```
ecommerce/
├── backend/
│   ├── src/
│   │   ├── index.js                  # Express app entry point
│   │   ├── config/
│   │   │   ├── db.js                 # PostgreSQL pool + connect with retry
│   │   │   └── redis.js              # Redis client
│   │   ├── middleware/
│   │   │   └── auth.js               # JWT authentication middleware
│   │   ├── routes/
│   │   │   ├── auth.js               # POST /register, POST /login
│   │   │   ├── products.js           # GET /products, GET /products/:id
│   │   │   ├── cart.js               # CRUD cart (protected)
│   │   │   └── orders.js             # Place & view orders (protected)
│   │   └── controllers/
│   │       ├── authController.js     # Register, login, profile logic
│   │       ├── productController.js  # Product queries + Redis cache
│   │       ├── cartController.js     # Cart stored in Redis
│   │       └── orderController.js    # Order placement with DB transaction
│   ├── Dockerfile                    # Multi-stage: deps → production
│   ├── .dockerignore
│   └── package.json
│
├── frontend/
│   ├── src/
│   │   ├── main.jsx                  # React entry point
│   │   ├── App.jsx                   # Router + providers
│   │   ├── index.css                 # Tailwind CSS
│   │   ├── context/
│   │   │   ├── AuthContext.jsx       # JWT auth state
│   │   │   └── CartContext.jsx       # Cart state
│   │   ├── services/
│   │   │   └── api.js                # Axios instance
│   │   ├── components/
│   │   │   ├── Navbar.jsx            # Top navigation
│   │   │   └── ProductCard.jsx       # Product grid card
│   │   └── pages/
│   │       ├── Home.jsx              # Product listing + search
│   │       ├── ProductDetail.jsx     # Single product view
│   │       ├── Cart.jsx              # Cart + checkout
│   │       ├── Login.jsx             # Login form
│   │       ├── Register.jsx          # Register form
│   │       └── Orders.jsx            # Order history
│   ├── Dockerfile                    # Multi-stage: build → production (nginx)
│   ├── nginx.conf                    # SPA routing + API proxy
│   ├── .dockerignore
│   ├── vite.config.js
│   └── package.json
│
├── postgres/
│   └── init.sql                      # Schema + 15 seed products
│
├── .env                              # Environment variables
├── .gitignore
├── docker-compose.yml                # Production Compose
└── docker-compose.dev.yml            # Dev overrides (hot reload)
```

---

## 4. Prerequisites

Ensure the following are installed:

```bash
# Check Docker
docker --version
# Docker version 24.0.0 or higher

# Check Docker Compose
docker compose version
# Docker Compose version v2.20.0 or higher

# Check available disk space (need at least 2GB)
df -h
```

| Tool | Minimum Version | Install |
|------|----------------|---------|
| Docker Desktop | 24.x | https://docs.docker.com/get-docker/ |
| Docker Compose | v2.20+ | Included with Docker Desktop |

---

## 5. Quick Start

### Step 1 — Clone / Download the project

```bash
# If using git
git clone https://github.com/yourusername/shopdock.git
cd shopdock

# Or navigate to the project folder
cd ecommerce
```

### Step 2 — Verify your `.env` file

The `.env` file is already configured for local use. For production, change secrets:

```bash
cat .env
```

```env
POSTGRES_USER=ecomuser
POSTGRES_PASSWORD=ecompassword
POSTGRES_DB=ecomdb
REDIS_URL=redis://cache:6379
JWT_SECRET=your_super_secret_jwt_key_change_in_production
PORT=5000
```

### Step 3 — Build and start all services

```bash
docker compose up -d --build
```

**Expected output:**

```
[+] Building 65.2s (22/22) FINISHED
 => [backend deps 1/3] FROM node:20-alpine                  8.2s
 => [backend deps 2/3] COPY package*.json ./                0.1s
 => [backend deps 3/3] RUN npm ci --only=production        14.3s
 => [backend production 1/3] COPY --from=deps node_modules  0.8s
 => [backend production 2/3] COPY src/ ./src/               0.1s
 => [frontend build 1/3] FROM node:20-alpine                0.0s
 => [frontend build 2/3] RUN npm ci                        18.4s
 => [frontend build 3/3] RUN npm run build                  9.1s
 => [frontend production] COPY --from=build /app/dist ...   0.2s

[+] Running 6/6
 ✔ Network ecommerce_ecom_network    Created    0.1s
 ✔ Volume "ecommerce_postgres_data"  Created    0.0s
 ✔ Volume "ecommerce_redis_data"     Created    0.0s
 ✔ Container ecom_db                 Healthy   18.3s
 ✔ Container ecom_cache              Healthy    2.1s
 ✔ Container ecom_backend            Started   19.4s
 ✔ Container ecom_frontend           Started   20.1s
```

### Step 4 — Verify all services are running

```bash
docker compose ps
```

```
NAME            IMAGE                       STATUS              PORTS
ecom_backend    ecommerce-backend           Up 2 minutes (healthy)
ecom_cache      redis:7-alpine              Up 2 minutes (healthy)
ecom_db         postgres:15-alpine          Up 2 minutes (healthy)
ecom_frontend   ecommerce-frontend          Up 2 minutes        0.0.0.0:3000->80/tcp
```

### Step 5 — Open the app

Open your browser at: **http://localhost:3000**

You should see the ShopDock homepage with 15 pre-loaded products.

---

## 6. How Each Service Works

### 🗄️ PostgreSQL (`db`)

The database initializes automatically using `postgres/init.sql`.

- Creates 4 tables: `users`, `products`, `orders`, `order_items`
- Seeds 15 products across 5 categories
- Adds indexes for query performance

```bash
# Connect to PostgreSQL directly
docker compose exec db psql -U ecomuser -d ecomdb

# Useful queries
\dt                              -- list all tables
SELECT name, price FROM products LIMIT 5;
SELECT COUNT(*) FROM products;
\q                               -- quit
```

**Expected output:**
```
              List of relations
 Schema |    Name     | Type  |  Owner
--------+-------------+-------+----------
 public | order_items | table | ecomuser
 public | orders      | table | ecomuser
 public | products    | table | ecomuser
 public | users       | table | ecomuser
```

---

### 🔴 Redis (`cache`)

Redis serves two purposes:

**1. Product caching** — Products are cached for 5 minutes to reduce DB load.

```bash
# Connect to Redis CLI
docker compose exec cache redis-cli

# Inspect cached keys
KEYS *
# Output: 1) "products:all::1:12"

# View a cached product list
GET "products:all::1:12"

# View a cart
KEYS cart:*

# Check TTL on a cache key
TTL "products:all::1:12"
# Output: 287 (seconds remaining)
```

**2. Shopping cart** — Each user's cart is stored as a JSON value with a 24-hour TTL.

```bash
# Check cart for user ID 1
GET cart:1
# Output: '[{"productId":1,"quantity":2},{"productId":4,"quantity":1}]'
```

---

### ⚙️ Backend (`backend`)

Node.js + Express REST API.

```bash
# View live backend logs
docker compose logs -f backend

# Test the health endpoint
curl http://localhost:3000/api/health
```

**Expected:**
```json
{ "status": "ok", "timestamp": "2024-06-01T10:00:00.000Z" }
```

---

### 🌐 Frontend (`frontend`)

React SPA built with Vite, served by Nginx.

- Nginx serves static files
- Routes all `/api/*` requests to the backend container
- Handles React Router (SPA) — all paths serve `index.html`

```bash
# Check nginx config inside container
docker compose exec frontend cat /etc/nginx/conf.d/default.conf

# View nginx access logs
docker compose logs frontend
```

---

## 7. Docker Concepts Used

### Multi-Stage Builds

Both `backend/Dockerfile` and `frontend/Dockerfile` use multi-stage builds.

**Backend — before vs after:**

| Approach | Image Size |
|----------|-----------|
| Single stage (with devDependencies) | ~420MB |
| Multi-stage (production only) | ~95MB |

**Frontend — before vs after:**

| Approach | Image Size |
|----------|-----------|
| Single stage (Node.js serving) | ~680MB |
| Multi-stage (Nginx serving built files) | ~28MB |

```bash
# Check final image sizes
docker images | grep ecommerce
```

```
ecommerce-frontend   latest   a1b2...   28.4MB
ecommerce-backend    latest   c3d4...   94.7MB
```

---

### Volumes

```yaml
volumes:
  postgres_data:   # Persists database between restarts
  redis_data:      # Persists Redis AOF log between restarts
```

```bash
# List volumes
docker volume ls | grep ecommerce

# Inspect postgres volume
docker volume inspect ecommerce_postgres_data

# Output:
# "Mountpoint": "/var/lib/docker/volumes/ecommerce_postgres_data/_data"
```

---

### Health Checks

Services wait for dependencies to be **healthy**, not just started.

```yaml
db:
  healthcheck:
    test: ["CMD-SHELL", "pg_isready -U ecomuser -d ecomdb"]
    interval: 10s
    timeout: 5s
    retries: 10

backend:
  depends_on:
    db:
      condition: service_healthy   # waits for db to pass health check
```

```bash
# Check health status
docker inspect ecom_db | grep -A 5 '"Health"'
```

---

### `.dockerignore`

Both services exclude unnecessary files to reduce build context.

```bash
# See build context size in action
docker build -t test-backend ./backend 2>&1 | grep "context"
# Sending build context to Docker daemon  24.58kB   ← tiny!
```

---

### Networking

All containers communicate over a private bridge network `ecom_network`. Container names act as DNS hostnames:

| From container | Calls | Resolves to |
|----------------|-------|-------------|
| backend | `db:5432` | PostgreSQL container |
| backend | `cache:6379` | Redis container |
| frontend nginx | `backend:5000` | Backend container |

No ports are exposed externally except `3000` (frontend).

---

## 8. API Reference

### Authentication

| Method | Endpoint | Auth | Body | Description |
|--------|----------|------|------|-------------|
| POST | `/api/auth/register` | ✗ | `{ name, email, password }` | Register user |
| POST | `/api/auth/login` | ✗ | `{ email, password }` | Login, get JWT |
| GET | `/api/auth/profile` | ✓ | — | Get current user |

### Products

| Method | Endpoint | Auth | Query Params | Description |
|--------|----------|------|-------------|-------------|
| GET | `/api/products` | ✗ | `?search=&category=&page=&limit=` | List products |
| GET | `/api/products/:id` | ✗ | — | Single product |
| GET | `/api/products/categories` | ✗ | — | All categories |

### Cart

| Method | Endpoint | Auth | Body | Description |
|--------|----------|------|------|-------------|
| GET | `/api/cart` | ✓ | — | Get cart |
| POST | `/api/cart` | ✓ | `{ productId, quantity }` | Add to cart |
| PUT | `/api/cart/:productId` | ✓ | `{ quantity }` | Update quantity |
| DELETE | `/api/cart/:productId` | ✓ | — | Remove item |
| DELETE | `/api/cart` | ✓ | — | Clear cart |

### Orders

| Method | Endpoint | Auth | Body | Description |
|--------|----------|------|------|-------------|
| POST | `/api/orders` | ✓ | `{ address }` | Place order |
| GET | `/api/orders` | ✓ | — | List my orders |
| GET | `/api/orders/:id` | ✓ | — | Order detail |

### Test with curl

```bash
# 1. Register
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"John Doe","email":"john@example.com","password":"secret123"}'

# Expected output:
# {"user":{"id":1,"name":"John Doe","email":"john@example.com"},"token":"eyJhbG..."}

# 2. Login and save token
TOKEN=$(curl -s -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"john@example.com","password":"secret123"}' | grep -o '"token":"[^"]*"' | cut -d'"' -f4)

echo "Token: $TOKEN"

# 3. Get products
curl http://localhost:3000/api/products | python3 -m json.tool

# 4. Add to cart
curl -X POST http://localhost:3000/api/cart \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"productId":1,"quantity":2}'

# 5. View cart
curl http://localhost:3000/api/cart \
  -H "Authorization: Bearer $TOKEN"

# 6. Place order
curl -X POST http://localhost:3000/api/orders \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"address":"123 Docker Lane, Container City"}'

# Expected output:
# {"message":"Order placed!","order":{"id":1,"total":"179.98","status":"pending",...}}
```

---

## 9. Development Mode

For development with **hot reload** (changes reflected instantly):

```bash
# Start with dev overrides
docker compose -f docker-compose.yml -f docker-compose.dev.yml up -d --build
```

**What's different in dev mode:**

| Service | Production | Development |
|---------|-----------|-------------|
| Backend | `node src/index.js` | `nodemon src/index.js` (hot reload) |
| Frontend | Nginx serving built files | Vite dev server (HMR) |
| DB port | Not exposed | Exposed on `5432` |
| Redis port | Not exposed | Exposed on `6379` |

```bash
# Edit a backend file and watch it reload automatically
echo "// changed" >> backend/src/index.js

# Watch the backend restart
docker compose logs -f backend
# backend  | [nodemon] restarting due to changes...
# backend  | 🚀 Server running on port 5000
```

---

## 10. Useful Commands

### Service Management

```bash
# Start everything
docker compose up -d

# Start with rebuild
docker compose up -d --build

# Stop (keep data)
docker compose down

# Stop and delete all data (fresh start)
docker compose down -v

# Restart one service
docker compose restart backend

# Scale backend (load testing)
docker compose up -d --scale backend=3
```

### Logs

```bash
# All services
docker compose logs -f

# Specific service
docker compose logs -f backend
docker compose logs -f db
docker compose logs --tail=100 frontend
```

### Debugging

```bash
# Shell into backend
docker compose exec backend sh

# Shell into frontend nginx
docker compose exec frontend sh

# Shell into database
docker compose exec db psql -U ecomuser -d ecomdb

# Shell into Redis
docker compose exec cache redis-cli

# Check resource usage
docker stats

# Inspect a container
docker inspect ecom_backend
```

### Database Operations

```bash
# View all users
docker compose exec db psql -U ecomuser -d ecomdb -c "SELECT id, name, email FROM users;"

# View all orders
docker compose exec db psql -U ecomuser -d ecomdb -c "SELECT * FROM orders;"

# View product stock
docker compose exec db psql -U ecomuser -d ecomdb -c "SELECT name, stock FROM products ORDER BY stock;"

# Reset the database (delete data and re-seed)
docker compose down -v
docker compose up -d --build
```

### Image Management

```bash
# View image sizes
docker images | grep ecommerce

# Remove dangling images (build cache cleanup)
docker image prune -f

# Full cleanup
docker system prune -af --volumes
```

---

## 11. Practice Exercises

Work through these exercises to reinforce Docker concepts.

---

### Exercise 1 — Understand the Build Context

```bash
# 1. Temporarily rename .dockerignore
mv backend/.dockerignore backend/.dockerignore.bak

# 2. Build and note the context size
docker build -t test-no-ignore ./backend 2>&1 | grep "context"

# 3. Restore .dockerignore
mv backend/.dockerignore.bak backend/.dockerignore

# 4. Build again with .dockerignore
docker build -t test-with-ignore ./backend 2>&1 | grep "context"

# Question: What is the difference in context size?
```

---

### Exercise 2 — Inspect Multi-Stage Build

```bash
# Build only the 'deps' stage of the backend
docker build --target deps -t backend-deps ./backend

# Build the full production image
docker build --target production -t backend-prod ./backend

# Compare sizes
docker images | grep backend

# Question: How much smaller is the production image?
```

---

### Exercise 3 — Explore the Network

```bash
# 1. Start all services
docker compose up -d

# 2. Shell into the backend
docker compose exec backend sh

# 3. Inside the container, ping the database by name
ping db
# You should see: PING db (172.x.x.x)

# 4. Connect to Redis from backend container
nc -zv cache 6379
# Connection to cache 6379 port [tcp] succeeded!

# 5. Try pinging something outside the network
ping google.com
# This works too — containers have outbound internet access

exit
```

---

### Exercise 4 — Test Redis Caching

```bash
# 1. Connect to Redis CLI
docker compose exec cache redis-cli

# 2. In another terminal, call the products API
curl http://localhost:3000/api/products > /dev/null

# 3. Back in Redis CLI, check for cache keys
KEYS *
# 1) "products:all::1:12"

# 4. Check the TTL
TTL "products:all::1:12"
# 287  (seconds remaining)

# 5. Fetch the cached value
GET "products:all::1:12"
# Returns JSON of all products

# 6. Call the API again and notice "cached": true in response
curl http://localhost:3000/api/products | python3 -m json.tool | grep cached
```

---

### Exercise 5 — Volume Persistence

```bash
# 1. Register a new user through the API or UI
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@test.com","password":"test123"}'

# 2. Stop containers (WITHOUT -v so volumes are kept)
docker compose down

# 3. Start again
docker compose up -d

# 4. Try to login — the user still exists!
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"test123"}'

# 5. Now try with -v (deletes volumes)
docker compose down -v
docker compose up -d

# 6. Try to login again — user is gone (fresh database)
```

---

### Exercise 6 — Health Check Deep Dive

```bash
# 1. Check health of all containers
docker compose ps

# 2. Inspect health details
docker inspect ecom_db | python3 -m json.tool | grep -A 20 '"Health"'

# 3. Watch the backend — it waits for DB to be healthy
docker compose logs backend | grep "Waiting\|connected"

# 4. Simulate DB failure
docker compose stop db

# 5. Watch backend retry connections
docker compose logs -f backend
# ⏳ Waiting for DB... (9 retries left)
# ⏳ Waiting for DB... (8 retries left)

# 6. Restore DB
docker compose start db

# 7. Watch backend reconnect
docker compose logs -f backend
# ✅ PostgreSQL connected
```

---

### Exercise 7 — Build a Full User Journey

Complete the following in the browser at `http://localhost:3000`:

1. Browse products on the home page
2. Use the search bar to find "keyboard"
3. Filter products by "Electronics" category
4. Click on a product to view its detail page
5. Click "Sign Up" and create an account
6. Add 3 different products to your cart
7. Go to the cart and adjust quantities
8. Enter a delivery address and place the order
9. Go to "My Orders" to see your order history

Then verify in the database:

```bash
docker compose exec db psql -U ecomuser -d ecomdb -c "
SELECT o.id, u.name, o.total, o.status, o.created_at
FROM orders o JOIN users u ON o.user_id = u.id;"
```

---

## 12. Troubleshooting

### Port 3000 already in use

```bash
# Find and kill the process using port 3000
lsof -i :3000
kill -9 <PID>

# Or change the port in docker-compose.yml
ports:
  - "3001:80"   # use 3001 instead
```

### Backend can't connect to database

```bash
# Check if db is healthy
docker compose ps db

# View db startup logs
docker compose logs db

# Restart just the backend (after db is healthy)
docker compose restart backend
```

### Changes not reflected after editing code

```bash
# Rebuild the changed service
docker compose up -d --build backend

# Or use dev mode for hot reload
docker compose -f docker-compose.yml -f docker-compose.dev.yml up -d
```

### Out of disk space

```bash
# Check Docker disk usage
docker system df

# Clean up everything (WARNING: removes all unused images/containers/volumes)
docker system prune -af --volumes
```

### Reset everything (fresh start)

```bash
docker compose down -v --rmi all
docker compose up -d --build
```

---

## Summary

You've built and deployed a full-stack e-commerce application using:

| Concept | Where Used |
|---------|-----------|
| Multi-stage builds | `backend/Dockerfile`, `frontend/Dockerfile` |
| `.dockerignore` | Reduces build context in both services |
| Named volumes | `postgres_data`, `redis_data` |
| Health checks | `db`, `cache`, `backend`, `frontend` |
| `depends_on` with conditions | Backend waits for healthy DB & Redis |
| `.env` files | All secrets and config in one place |
| Custom networks | `ecom_network` isolates all services |
| Nginx reverse proxy | Routes `/api/*` to backend inside Docker |
| Redis caching | Products cached, cart stored in memory |
| PostgreSQL transactions | Stock deduction on order placement |

---

*Happy shipping! 🐳 — ShopDock is your Docker playground.*
