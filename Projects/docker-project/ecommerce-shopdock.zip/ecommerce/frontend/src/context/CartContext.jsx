import { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';
import { useAuth } from './AuthContext';

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const { token } = useAuth();
  const [cart, setCart] = useState({ items: [], total: 0 });

  const fetchCart = async () => {
    if (!token) return setCart({ items: [], total: 0 });
    try {
      const res = await api.get('/cart');
      setCart(res.data);
    } catch { setCart({ items: [], total: 0 }); }
  };

  useEffect(() => { fetchCart(); }, [token]);

  const addToCart = async (productId, quantity = 1) => {
    await api.post('/cart', { productId, quantity });
    await fetchCart();
  };

  const updateCart = async (productId, quantity) => {
    await api.put(`/cart/${productId}`, { quantity });
    await fetchCart();
  };

  const removeFromCart = async (productId) => {
    await api.delete(`/cart/${productId}`);
    await fetchCart();
  };

  const clearCart = async () => {
    await api.delete('/cart');
    setCart({ items: [], total: 0 });
  };

  return (
    <CartContext.Provider value={{ cart, addToCart, updateCart, removeFromCart, clearCart, fetchCart }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
