import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const { addToCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    api.get(`/products/${id}`).then(r => setProduct(r.data)).catch(() => navigate('/'));
  }, [id]);

  if (!product) return <div className="flex justify-center items-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div></div>;

  const handleAdd = async () => {
    if (!user) return navigate('/login');
    await addToCart(product.id, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg overflow-hidden">
      <div className="md:flex">
        <img
          src={product.image_url || `https://placehold.co/500x400?text=${encodeURIComponent(product.name)}`}
          alt={product.name}
          className="w-full md:w-1/2 h-72 md:h-auto object-cover"
        />
        <div className="p-8 flex flex-col justify-center flex-1">
          <span className="text-sm text-blue-600 font-semibold uppercase tracking-widest">{product.category}</span>
          <h1 className="text-3xl font-bold mt-2 mb-4">{product.name}</h1>
          <p className="text-gray-600 mb-6">{product.description}</p>
          <p className="text-4xl font-bold text-blue-700 mb-4">${parseFloat(product.price).toFixed(2)}</p>
          <p className={`text-sm mb-6 font-medium ${product.stock > 0 ? 'text-green-600' : 'text-red-500'}`}>
            {product.stock > 0 ? `✓ ${product.stock} units available` : '✗ Out of stock'}
          </p>

          {product.stock > 0 && (
            <div className="flex items-center gap-4 mb-6">
              <label className="text-sm font-medium">Quantity:</label>
              <div className="flex items-center border rounded-lg overflow-hidden">
                <button onClick={() => setQty(q => Math.max(1, q - 1))} className="px-3 py-2 bg-gray-100 hover:bg-gray-200 font-bold">−</button>
                <span className="px-4 py-2 font-semibold">{qty}</span>
                <button onClick={() => setQty(q => Math.min(product.stock, q + 1))} className="px-3 py-2 bg-gray-100 hover:bg-gray-200 font-bold">+</button>
              </div>
            </div>
          )}

          <button
            onClick={handleAdd}
            disabled={product.stock === 0}
            className={`py-3 px-8 rounded-xl font-semibold text-lg transition ${
              added ? 'bg-green-500 text-white' :
              product.stock === 0 ? 'bg-gray-200 text-gray-400 cursor-not-allowed' :
              'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            {added ? '✓ Added to Cart!' : 'Add to Cart 🛒'}
          </button>
        </div>
      </div>
    </div>
  );
}
