import { useState, useEffect } from 'react';
import api from '../services/api';

const STATUS_COLOR = {
  pending: 'bg-yellow-100 text-yellow-700',
  processing: 'bg-blue-100 text-blue-700',
  shipped: 'bg-purple-100 text-purple-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
};

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [detail, setDetail] = useState(null);

  useEffect(() => {
    api.get('/orders').then(r => setOrders(r.data)).finally(() => setLoading(false));
  }, []);

  const viewOrder = async (id) => {
    setSelected(id);
    const res = await api.get(`/orders/${id}`);
    setDetail(res.data);
  };

  if (loading) return <div className="flex justify-center items-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div></div>;

  if (!orders.length) return (
    <div className="text-center py-20">
      <p className="text-6xl mb-4">📦</p>
      <h2 className="text-2xl font-bold">No orders yet</h2>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">My Orders</h1>
      <div className="space-y-4">
        {orders.map(order => (
          <div key={order.id} className="bg-white rounded-xl shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <div>
                <span className="font-bold text-lg">Order #{order.id}</span>
                <span className="ml-3 text-gray-400 text-sm">{new Date(order.created_at).toLocaleDateString()}</span>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium capitalize ${STATUS_COLOR[order.status] || 'bg-gray-100 text-gray-700'}`}>
                {order.status}
              </span>
            </div>
            <p className="text-gray-600 text-sm mb-2">📍 {order.address}</p>
            <div className="flex items-center justify-between">
              <span className="font-bold text-blue-700 text-xl">${parseFloat(order.total).toFixed(2)}</span>
              <button onClick={() => viewOrder(order.id)}
                className="text-blue-600 hover:underline text-sm font-medium">
                {selected === order.id ? 'Hide Details ▲' : 'View Details ▼'}
              </button>
            </div>

            {selected === order.id && detail && (
              <div className="mt-4 pt-4 border-t">
                <h4 className="font-semibold mb-3 text-gray-700">Items:</h4>
                <div className="space-y-2">
                  {detail.items.map(item => (
                    <div key={item.product_id} className="flex items-center gap-3">
                      <img
                        src={item.image_url || `https://placehold.co/50x50?text=${encodeURIComponent(item.name)}`}
                        alt={item.name}
                        className="w-12 h-12 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-sm">{item.name}</p>
                        <p className="text-gray-500 text-xs">Qty: {item.quantity} × ${parseFloat(item.price).toFixed(2)}</p>
                      </div>
                      <p className="font-semibold text-sm">${(item.quantity * parseFloat(item.price)).toFixed(2)}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
