import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import api from '../services/api';

export default function Cart() {
  const { cart, updateCart, removeFromCart, clearCart } = useCart();
  const [address, setAddress] = useState('');
  const [ordering, setOrdering] = useState(false);
  const navigate = useNavigate();

  const handleOrder = async () => {
    if (!address.trim()) return alert('Please enter a delivery address');
    setOrdering(true);
    try {
      const res = await api.post('/orders', { address });
      alert(`✅ Order #${res.data.order.id} placed successfully!`);
      navigate('/orders');
    } catch (err) {
      alert(err.response?.data?.error || 'Order failed');
    } finally {
      setOrdering(false);
    }
  };

  if (!cart.items.length) return (
    <div className="text-center py-20">
      <p className="text-6xl mb-4">🛒</p>
      <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
      <Link to="/" className="mt-4 inline-block bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">Browse Products</Link>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>
      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-4">
          {cart.items.map(({ product, quantity }) => (
            <div key={product.id} className="bg-white rounded-xl shadow p-4 flex items-center gap-4">
              <img
                src={product.image_url || `https://placehold.co/80x80?text=${encodeURIComponent(product.name)}`}
                alt={product.name}
                className="w-20 h-20 object-cover rounded-lg"
              />
              <div className="flex-1">
                <h3 className="font-semibold">{product.name}</h3>
                <p className="text-blue-700 font-bold">${parseFloat(product.price).toFixed(2)}</p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => updateCart(product.id, quantity - 1)} disabled={quantity <= 1}
                  className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 font-bold disabled:opacity-40">−</button>
                <span className="w-8 text-center font-semibold">{quantity}</span>
                <button onClick={() => updateCart(product.id, quantity + 1)}
                  className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 font-bold">+</button>
              </div>
              <p className="font-bold w-20 text-right">${(parseFloat(product.price) * quantity).toFixed(2)}</p>
              <button onClick={() => removeFromCart(product.id)} className="text-red-400 hover:text-red-600 text-lg">✕</button>
            </div>
          ))}
          <button onClick={clearCart} className="text-sm text-red-500 hover:underline">Clear cart</button>
        </div>

        <div className="bg-white rounded-xl shadow p-6 h-fit">
          <h2 className="text-xl font-bold mb-4">Order Summary</h2>
          <div className="flex justify-between mb-2 text-gray-600"><span>Items ({cart.items.length})</span><span>${cart.total}</span></div>
          <div className="flex justify-between mb-4 text-gray-600"><span>Shipping</span><span className="text-green-600">Free</span></div>
          <div className="border-t pt-4 flex justify-between font-bold text-lg mb-6"><span>Total</span><span>${cart.total}</span></div>

          <textarea
            placeholder="Enter delivery address..."
            value={address}
            onChange={e => setAddress(e.target.value)}
            className="w-full border rounded-lg p-3 text-sm mb-4 focus:outline-none focus:ring-2 focus:ring-blue-400 resize-none"
            rows={3}
          />
          <button
            onClick={handleOrder}
            disabled={ordering}
            className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 disabled:opacity-50 transition"
          >
            {ordering ? 'Placing Order...' : 'Place Order'}
          </button>
        </div>
      </div>
    </div>
  );
}
