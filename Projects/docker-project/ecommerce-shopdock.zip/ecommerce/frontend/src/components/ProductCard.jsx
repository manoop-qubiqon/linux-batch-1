import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useState } from 'react';

export default function ProductCard({ product }) {
  const { addToCart } = useCart();
  const { user } = useAuth();
  const [added, setAdded] = useState(false);

  const handleAdd = async () => {
    if (!user) return alert('Please login to add items to cart');
    await addToCart(product.id, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <div className="bg-white rounded-xl shadow hover:shadow-lg transition overflow-hidden flex flex-col">
      <Link to={`/products/${product.id}`}>
        <img
          src={product.image_url || `https://placehold.co/400x300?text=${encodeURIComponent(product.name)}`}
          alt={product.name}
          className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300"
        />
      </Link>
      <div className="p-4 flex flex-col flex-1">
        <span className="text-xs text-blue-600 font-medium uppercase tracking-wide mb-1">{product.category}</span>
        <Link to={`/products/${product.id}`} className="font-semibold text-gray-800 hover:text-blue-700 mb-1">{product.name}</Link>
        <p className="text-gray-500 text-sm flex-1 line-clamp-2">{product.description}</p>
        <div className="flex items-center justify-between mt-4">
          <span className="text-xl font-bold text-blue-700">${parseFloat(product.price).toFixed(2)}</span>
          <span className={`text-xs ${product.stock > 0 ? 'text-green-600' : 'text-red-500'}`}>
            {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
          </span>
        </div>
        <button
          onClick={handleAdd}
          disabled={product.stock === 0}
          className={`mt-3 w-full py-2 rounded-lg font-medium transition text-sm ${
            added ? 'bg-green-500 text-white' :
            product.stock === 0 ? 'bg-gray-200 text-gray-400 cursor-not-allowed' :
            'bg-blue-600 text-white hover:bg-blue-700'
          }`}
        >
          {added ? '✓ Added!' : product.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
        </button>
      </div>
    </div>
  );
}
