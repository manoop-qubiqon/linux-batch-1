import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { cart } = useCart();
  const navigate = useNavigate();
  const itemCount = cart.items.reduce((sum, i) => sum + i.quantity, 0);

  const handleLogout = () => { logout(); navigate('/'); };

  return (
    <nav className="bg-blue-700 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold tracking-tight">🛍️ ShopDock</Link>
        <div className="flex items-center gap-6">
          <Link to="/" className="hover:text-blue-200 transition">Products</Link>
          {user ? (
            <>
              <Link to="/orders" className="hover:text-blue-200 transition">My Orders</Link>
              <Link to="/cart" className="relative hover:text-blue-200 transition">
                🛒 Cart
                {itemCount > 0 && (
                  <span className="absolute -top-2 -right-3 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">{itemCount}</span>
                )}
              </Link>
              <span className="text-blue-200 text-sm">Hi, {user.name}</span>
              <button onClick={handleLogout} className="bg-blue-600 hover:bg-blue-500 px-3 py-1 rounded text-sm transition">Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="hover:text-blue-200 transition">Login</Link>
              <Link to="/register" className="bg-white text-blue-700 px-3 py-1 rounded font-medium hover:bg-blue-50 transition">Sign Up</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
