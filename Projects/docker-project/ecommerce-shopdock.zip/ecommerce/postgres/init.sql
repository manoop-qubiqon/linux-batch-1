-- ─────────────────────────────────────────
-- ShopDock E-Commerce Database Schema
-- ─────────────────────────────────────────

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id          SERIAL PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  email       VARCHAR(150) UNIQUE NOT NULL,
  password    VARCHAR(255) NOT NULL,
  created_at  TIMESTAMP DEFAULT NOW()
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id          SERIAL PRIMARY KEY,
  name        VARCHAR(200) NOT NULL,
  description TEXT,
  price       NUMERIC(10, 2) NOT NULL,
  stock       INTEGER DEFAULT 0,
  category    VARCHAR(100),
  image_url   TEXT,
  created_at  TIMESTAMP DEFAULT NOW()
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER REFERENCES users(id),
  total       NUMERIC(10, 2) NOT NULL,
  address     TEXT NOT NULL,
  status      VARCHAR(50) DEFAULT 'pending',
  created_at  TIMESTAMP DEFAULT NOW()
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
  id          SERIAL PRIMARY KEY,
  order_id    INTEGER REFERENCES orders(id) ON DELETE CASCADE,
  product_id  INTEGER REFERENCES products(id),
  quantity    INTEGER NOT NULL,
  price       NUMERIC(10, 2) NOT NULL
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);

-- ─────────────────────────────────────────
-- Seed Data
-- ─────────────────────────────────────────

INSERT INTO products (name, description, price, stock, category, image_url) VALUES
-- Electronics
('Wireless Noise-Cancelling Headphones',
 'Premium over-ear headphones with 40-hour battery life and active noise cancellation.',
 89.99, 50, 'Electronics',
 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400'),

('Mechanical Keyboard',
 'TKL mechanical keyboard with RGB lighting and Cherry MX Blue switches.',
 129.99, 30, 'Electronics',
 'https://images.unsplash.com/photo-1595225476474-87563907a212?w=400'),

('USB-C Hub 7-in-1',
 'Compact hub with HDMI 4K, 3x USB-A, SD card, and 100W PD charging.',
 39.99, 75, 'Electronics',
 'https://images.unsplash.com/photo-1625842268584-8f3296236761?w=400'),

('Wireless Charging Pad',
 '15W fast wireless charger compatible with all Qi-enabled devices.',
 24.99, 100, 'Electronics',
 'https://images.unsplash.com/photo-1608556216113-81e93be7e8e5?w=400'),

-- Clothing
('Classic Cotton T-Shirt',
 'Premium 100% organic cotton t-shirt. Available in multiple colors.',
 19.99, 200, 'Clothing',
 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400'),

('Slim Fit Chinos',
 'Versatile stretch chinos perfect for casual or smart-casual occasions.',
 49.99, 80, 'Clothing',
 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=400'),

('Hoodie Sweatshirt',
 'Cozy fleece-lined hoodie with kangaroo pocket and adjustable drawstring.',
 44.99, 60, 'Clothing',
 'https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=400'),

-- Books
('Docker Deep Dive',
 'A complete guide to Docker from beginner to advanced. Covers containers, Compose, and Swarm.',
 29.99, 150, 'Books',
 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400'),

('Clean Code',
 'A handbook of agile software craftsmanship by Robert C. Martin.',
 34.99, 90, 'Books',
 'https://images.unsplash.com/photo-1589998059171-988d887df646?w=400'),

('The Pragmatic Programmer',
 'Your journey to mastery — essential reading for every developer.',
 37.99, 70, 'Books',
 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400'),

-- Home & Kitchen
('Pour-Over Coffee Set',
 'Borosilicate glass dripper and server set for the perfect pour-over brew.',
 54.99, 40, 'Home & Kitchen',
 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400'),

('Ceramic Plant Pot Set',
 'Set of 3 minimalist ceramic pots with drainage holes and bamboo trays.',
 32.99, 55, 'Home & Kitchen',
 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=400'),

-- Sports
('Yoga Mat',
 'Non-slip 6mm thick eco-friendly TPE yoga mat with alignment lines.',
 34.99, 85, 'Sports',
 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400'),

('Resistance Bands Set',
 'Set of 5 latex resistance bands with handles, ankle straps, and door anchor.',
 22.99, 120, 'Sports',
 'https://images.unsplash.com/photo-1598289431512-b97b0917affc?w=400'),

('Water Bottle 1L',
 'Insulated stainless steel bottle keeps drinks cold 24h or hot 12h.',
 27.99, 95, 'Sports',
 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400');
