const express = require('express');
const router = express.Router();
const {
  getAllProducts,
  getProduct,
  getCategories,
} = require('../controllers/productController');

router.get('/', getAllProducts);
router.get('/categories', getCategories);
router.get('/:id', getProduct);

module.exports = router;
