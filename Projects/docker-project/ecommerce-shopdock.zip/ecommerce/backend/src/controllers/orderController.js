const { pool } = require('../config/db');
const { getRedis } = require('../config/redis');

const cartKey = (userId) => `cart:${userId}`;

const placeOrder = async (req, res) => {
  const { address } = req.body;
  if (!address) return res.status(400).json({ error: 'Delivery address required' });

  const redis = getRedis();
  const raw = await redis.get(cartKey(req.user.id));
  const items = raw ? JSON.parse(raw) : [];
  if (!items.length) return res.status(400).json({ error: 'Cart is empty' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    let total = 0;
    const enriched = [];

    for (const item of items) {
      const res = await client.query('SELECT * FROM products WHERE id=$1 FOR UPDATE', [item.productId]);
      const product = res.rows[0];
      if (!product) throw new Error(`Product ${item.productId} not found`);
      if (product.stock < item.quantity) throw new Error(`Insufficient stock for ${product.name}`);

      await client.query('UPDATE products SET stock=stock-$1 WHERE id=$2', [item.quantity, product.id]);
      total += parseFloat(product.price) * item.quantity;
      enriched.push({ productId: product.id, name: product.name, price: product.price, quantity: item.quantity });
    }

    const orderResult = await client.query(
      'INSERT INTO orders (user_id, total, address, status) VALUES ($1,$2,$3,$4) RETURNING *',
      [req.user.id, total.toFixed(2), address, 'pending']
    );
    const order = orderResult.rows[0];

    for (const item of enriched) {
      await client.query(
        'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($1,$2,$3,$4)',
        [order.id, item.productId, item.quantity, item.price]
      );
    }

    await client.query('COMMIT');
    await redis.del(cartKey(req.user.id));

    res.status(201).json({ message: 'Order placed!', order: { ...order, items: enriched } });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: err.message || 'Order failed' });
  } finally {
    client.release();
  }
};

const getOrders = async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM orders WHERE user_id=$1 ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch orders' });
  }
};

const getOrder = async (req, res) => {
  const { id } = req.params;
  try {
    const orderRes = await pool.query('SELECT * FROM orders WHERE id=$1 AND user_id=$2', [id, req.user.id]);
    if (!orderRes.rows.length) return res.status(404).json({ error: 'Order not found' });

    const itemsRes = await pool.query(
      `SELECT oi.*, p.name, p.image_url FROM order_items oi
       JOIN products p ON oi.product_id = p.id
       WHERE oi.order_id=$1`, [id]
    );
    res.json({ ...orderRes.rows[0], items: itemsRes.rows });
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch order' });
  }
};

module.exports = { placeOrder, getOrders, getOrder };
