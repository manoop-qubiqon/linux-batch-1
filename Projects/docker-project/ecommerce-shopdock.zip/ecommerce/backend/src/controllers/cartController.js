const { getRedis } = require('../config/redis');
const { pool } = require('../config/db');

const cartKey = (userId) => `cart:${userId}`;

const getCart = async (req, res) => {
  const redis = getRedis();
  const raw = await redis.get(cartKey(req.user.id));
  const items = raw ? JSON.parse(raw) : [];

  if (!items.length) return res.json({ items: [], total: 0 });

  const ids = items.map(i => i.productId);
  const result = await pool.query(`SELECT * FROM products WHERE id = ANY($1)`, [ids]);
  const products = result.rows;

  const enriched = items.map(item => {
    const product = products.find(p => p.id === item.productId);
    return product ? { ...item, product } : null;
  }).filter(Boolean);

  const total = enriched.reduce((sum, i) => sum + i.quantity * parseFloat(i.product.price), 0);
  res.json({ items: enriched, total: total.toFixed(2) });
};

const addToCart = async (req, res) => {
  const { productId, quantity = 1 } = req.body;
  if (!productId) return res.status(400).json({ error: 'productId required' });

  const product = await pool.query('SELECT id, stock FROM products WHERE id=$1', [productId]);
  if (!product.rows.length) return res.status(404).json({ error: 'Product not found' });
  if (product.rows[0].stock < quantity) return res.status(400).json({ error: 'Insufficient stock' });

  const redis = getRedis();
  const raw = await redis.get(cartKey(req.user.id));
  const items = raw ? JSON.parse(raw) : [];

  const existing = items.find(i => i.productId === productId);
  if (existing) existing.quantity += quantity;
  else items.push({ productId, quantity });

  await redis.setEx(cartKey(req.user.id), 86400, JSON.stringify(items));
  res.json({ message: 'Added to cart', items });
};

const updateCart = async (req, res) => {
  const { productId } = req.params;
  const { quantity } = req.body;
  if (!quantity || quantity < 1) return res.status(400).json({ error: 'Valid quantity required' });

  const redis = getRedis();
  const raw = await redis.get(cartKey(req.user.id));
  const items = raw ? JSON.parse(raw) : [];

  const item = items.find(i => i.productId === parseInt(productId));
  if (!item) return res.status(404).json({ error: 'Item not in cart' });

  item.quantity = quantity;
  await redis.setEx(cartKey(req.user.id), 86400, JSON.stringify(items));
  res.json({ message: 'Cart updated', items });
};

const removeFromCart = async (req, res) => {
  const { productId } = req.params;
  const redis = getRedis();
  const raw = await redis.get(cartKey(req.user.id));
  const items = raw ? JSON.parse(raw) : [];

  const updated = items.filter(i => i.productId !== parseInt(productId));
  await redis.setEx(cartKey(req.user.id), 86400, JSON.stringify(updated));
  res.json({ message: 'Item removed', items: updated });
};

const clearCart = async (req, res) => {
  const redis = getRedis();
  await redis.del(cartKey(req.user.id));
  res.json({ message: 'Cart cleared' });
};

module.exports = { getCart, addToCart, updateCart, removeFromCart, clearCart };
