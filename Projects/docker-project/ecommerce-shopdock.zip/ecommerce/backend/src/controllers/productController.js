const { pool } = require('../config/db');
const { getRedis } = require('../config/redis');

const CACHE_TTL = 300; // 5 minutes

const getAllProducts = async (req, res) => {
  const { category, search, page = 1, limit = 12 } = req.query;
  const offset = (page - 1) * limit;
  const cacheKey = `products:${category || 'all'}:${search || ''}:${page}:${limit}`;

  try {
    const redis = getRedis();
    const cached = await redis.get(cacheKey);
    if (cached) return res.json({ ...JSON.parse(cached), cached: true });

    let query = 'SELECT * FROM products WHERE 1=1';
    const params = [];

    if (category) { params.push(category); query += ` AND category=$${params.length}`; }
    if (search)   { params.push(`%${search}%`); query += ` AND (name ILIKE $${params.length} OR description ILIKE $${params.length})`; }

    const countResult = await pool.query(query.replace('SELECT *', 'SELECT COUNT(*)'), params);
    const total = parseInt(countResult.rows[0].count);

    params.push(limit, offset);
    query += ` ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`;

    const result = await pool.query(query, params);
    const data = { products: result.rows, total, page: parseInt(page), pages: Math.ceil(total / limit) };

    await redis.setEx(cacheKey, CACHE_TTL, JSON.stringify(data));
    res.json({ ...data, cached: false });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch products' });
  }
};

const getProduct = async (req, res) => {
  const { id } = req.params;
  const cacheKey = `product:${id}`;

  try {
    const redis = getRedis();
    const cached = await redis.get(cacheKey);
    if (cached) return res.json(JSON.parse(cached));

    const result = await pool.query('SELECT * FROM products WHERE id=$1', [id]);
    if (!result.rows.length) return res.status(404).json({ error: 'Product not found' });

    await redis.setEx(cacheKey, CACHE_TTL, JSON.stringify(result.rows[0]));
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch product' });
  }
};

const getCategories = async (req, res) => {
  try {
    const result = await pool.query('SELECT DISTINCT category FROM products ORDER BY category');
    res.json(result.rows.map(r => r.category));
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch categories' });
  }
};

module.exports = { getAllProducts, getProduct, getCategories };
