const { createClient } = require('redis');

let client;

const connectRedis = async () => {
  client = createClient({
    url: process.env.REDIS_URL || 'redis://cache:6379',
  });

  client.on('error', (err) => console.error('Redis error:', err));

  await client.connect();
  console.log('✅ Redis connected');
};

const getRedis = () => client;

module.exports = { connectRedis, getRedis };
