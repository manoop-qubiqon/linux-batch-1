const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST || 'db',
  port: process.env.DB_PORT || 5432,
  user: process.env.DB_USER || 'ecomuser',
  password: process.env.DB_PASSWORD || 'ecompassword',
  database: process.env.DB_NAME || 'ecomdb',
});

const connectDB = async () => {
  let retries = 10;
  while (retries) {
    try {
      await pool.query('SELECT 1');
      console.log('✅ PostgreSQL connected');
      return;
    } catch (err) {
      retries -= 1;
      console.log(`⏳ Waiting for DB... (${retries} retries left)`);
      await new Promise(res => setTimeout(res, 3000));
    }
  }
  throw new Error('Could not connect to PostgreSQL');
};

module.exports = { pool, connectDB };
